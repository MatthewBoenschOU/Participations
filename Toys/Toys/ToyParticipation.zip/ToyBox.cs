﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Toys
{
    class ToyBox
    {

        public List<Toy> Toys { get; set; }

        public ToyBox()
        {
            Toys = new List<Toy>();
        }



    }
}
